package pe.edu.utp.academico;

import java.util.ArrayList;
import java.util.List;

public class RegistroAuditoria {

    private static final RegistroAuditoria INSTANCIA =
            new RegistroAuditoria();

    private final List<String> eventos = new ArrayList<>();

    private RegistroAuditoria() {
    }

    public static RegistroAuditoria getInstancia() {
        return INSTANCIA;
    }

    public void registrar(String evento) {
        eventos.add(evento);
    }

    public void mostrar() {
        for (String evento : eventos) {
            System.out.println("- " + evento);
        }
    }
}
