package pe.edu.utp.academico;

public class Docente {

    private String codigo;
    private String nombre;
    private String especialidad;

    public Docente(String codigo, String nombre, String especialidad) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.especialidad = especialidad;
    }

    public String getCodigo() {
        return codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public String getEspecialidad() {
        return especialidad;
    }

    @Override
    public String toString() {
        return nombre + " (" + codigo + ", " + especialidad + ")";
    }
}
