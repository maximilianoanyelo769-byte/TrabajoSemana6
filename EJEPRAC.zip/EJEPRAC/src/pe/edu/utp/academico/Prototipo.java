package pe.edu.utp.academico;

public interface Prototipo<T> {
    T copiar();
}
