package pe.edu.utp.academico;

public class GeneradorCodigos {

    private static final GeneradorCodigos INSTANCIA =
            new GeneradorCodigos();

    private int contador = 0;

    private GeneradorCodigos() {
    }

    public static GeneradorCodigos getInstancia() {
        return INSTANCIA;
    }

    public String generarCodigo() {
        contador++;
        return String.format("DP-%03d", contador);
    }
}
