package pe.edu.utp.academico;

public class Main {

    public static void main(String[] args) {

        System.out.println("========================================");
        System.out.println(" SISTEMA ACADEMICO");
        System.out.println(" SINGLETON Y PROTOTYPE");
        System.out.println("========================================\n");

        // =====================================================
        // PARTE 1: SINGLETON - CONFIGURACION ACADEMICA
        // =====================================================

        System.out.println("1. PRUEBA DE SINGLETON");
        System.out.println("----------------------------------------");

        ConfiguracionAcademica configuracionA =
                ConfiguracionAcademica.getInstancia();

        ConfiguracionAcademica configuracionB =
                ConfiguracionAcademica.getInstancia();

        configuracionA.setInstitucion("UTP");
        configuracionA.setPeriodo("2026-II");
        configuracionA.setMaximoCreditos(24);

        System.out.println("Configuracion A: "
                + configuracionA.resumen());

        System.out.println("Configuracion B: "
                + configuracionB.resumen());

        System.out.println("¿Es el mismo objeto? "
                + (configuracionA == configuracionB));

        System.out.println();


        // =====================================================
        // GENERADOR DE CODIGOS - SINGLETON
        // =====================================================

        System.out.println("2. GENERADOR DE CODIGOS");
        System.out.println("----------------------------------------");

        GeneradorCodigos generador1 =
                GeneradorCodigos.getInstancia();

        GeneradorCodigos generador2 =
                GeneradorCodigos.getInstancia();

        System.out.println("Codigo 1: "
                + generador1.generarCodigo());

        System.out.println("Codigo 2: "
                + generador1.generarCodigo());

        System.out.println("Codigo 3: "
                + generador2.generarCodigo());

        System.out.println("¿Es el mismo generador? "
                + (generador1 == generador2));

        System.out.println();


        // =====================================================
        // OBJETOS BASE
        // =====================================================

        Docente docente = new Docente(
                "D001",
                "Ana Torres",
                "Ingenieria de software"
        );

        Horario horario = new Horario(
                "Lunes",
                "08:00",
                "10:00"
        );

        Aula aula = new Aula(
                "A-101",
                40,
                "Laboratorio"
        );

        Evaluacion evaluacion = new Evaluacion(
                "Practica 1",
                20,
                "2026-10-15"
        );

        MaterialEducativo material = new MaterialEducativo(
                "Introduccion a Patrones",
                "PDF",
                "/materiales/patrones.pdf"
        );


        // =====================================================
        // CREACION DEL CURSO ORIGINAL
        // =====================================================

        Curso cursoA = new Curso(
                "DP101-A",
                "Diseno de Patrones",
                "A",
                4,
                docente,
                horario,
                aula,
                evaluacion,
                material
        );

        RegistroAuditoria.getInstancia().registrar(
                "Creacion del curso " + cursoA.getCodigo()
        );


        // =====================================================
        // PARTE 3: PROTOTYPE
        // =====================================================

        System.out.println("3. PRUEBA DE PROTOTYPE");
        System.out.println("----------------------------------------");

        System.out.println("CURSO ORIGINAL:");
        System.out.println(cursoA.resumen());

        System.out.println("\nCreando copia...");

        Curso cursoB = cursoA.copiar();

        cursoB.setCodigo(
                GeneradorCodigos.getInstancia().generarCodigo()
        );

        cursoB.setSeccion("B");

        cursoB.getHorario().setDia("Miercoles");

        cursoB.getAula().setCodigo("B-202");

        cursoB.getEvaluacion().setNombre("Practica 2");

        cursoB.getMaterialEducativo().setTitulo(
                "Prototype - Material para Seccion B"
        );

        System.out.println("\nCURSO ORIGINAL DESPUES DE MODIFICAR LA COPIA:");
        System.out.println(cursoA.resumen());

        System.out.println("\nCURSO COPIA:");
        System.out.println(cursoB.resumen());

        System.out.println();


        // =====================================================
        // COMPROBACION DE REFERENCIAS
        // =====================================================

        System.out.println("4. COMPROBACION DE COPIAS");
        System.out.println("----------------------------------------");

        System.out.println(
                "¿Curso original == copia? "
                        + (cursoA == cursoB)
        );

        System.out.println(
                "¿Horario original == horario copia? "
                        + (cursoA.getHorario() == cursoB.getHorario())
        );

        System.out.println(
                "¿Aula original == aula copia? "
                        + (cursoA.getAula() == cursoB.getAula())
        );

        System.out.println(
                "¿Evaluacion original == evaluacion copia? "
                        + (cursoA.getEvaluacion()
                        == cursoB.getEvaluacion())
        );

        System.out.println(
                "¿Material original == material copia? "
                        + (cursoA.getMaterialEducativo()
                        == cursoB.getMaterialEducativo())
        );

        System.out.println(
                "¿Docente original == docente copia? "
                        + (cursoA.getDocente()
                        == cursoB.getDocente())
        );

        System.out.println();


        // =====================================================
        // DETALLE DE LOS OBJETOS COPIADOS
        // =====================================================

        System.out.println("5. DETALLE DE LA COPIA");
        System.out.println("----------------------------------------");

        System.out.println("Horario A: "
                + cursoA.getHorario());

        System.out.println("Horario B: "
                + cursoB.getHorario());

        System.out.println("Aula A: "
                + cursoA.getAula());

        System.out.println("Aula B: "
                + cursoB.getAula());

        System.out.println("Evaluacion A: "
                + cursoA.getEvaluacion());

        System.out.println("Evaluacion B: "
                + cursoB.getEvaluacion());

        System.out.println("Material A: "
                + cursoA.getMaterialEducativo());

        System.out.println("Material B: "
                + cursoB.getMaterialEducativo());

        System.out.println();


        // =====================================================
        // ESTUDIANTE
        // =====================================================

        System.out.println("6. MATRICULA DEL ESTUDIANTE");
        System.out.println("----------------------------------------");

        Estudiante estudiante = new Estudiante(
                "U2026001",
                "Luis Ramos",
                "luis.ramos@utp.edu.pe"
        );

        estudiante.matricular(cursoA);
        estudiante.matricular(cursoB);

        System.out.println(estudiante.mostrarCursos());


        // =====================================================
        // REGISTRO DE AUDITORIA
        // =====================================================

        System.out.println("7. REGISTRO DE AUDITORIA");
        System.out.println("----------------------------------------");

        RegistroAuditoria auditoria1 =
                RegistroAuditoria.getInstancia();

        RegistroAuditoria auditoria2 =
                RegistroAuditoria.getInstancia();

        System.out.println("¿Es el mismo registro? "
                + (auditoria1 == auditoria2));

        auditoria1.mostrar();

        System.out.println();


        // =====================================================
        // RESULTADOS FINALES
        // =====================================================

        System.out.println("========================================");
        System.out.println(" PRUEBAS FINALES");
        System.out.println("========================================");

        System.out.println(
                "Singleton Configuracion: "
                        + (configuracionA == configuracionB)
        );

        System.out.println(
                "Singleton Generador: "
                        + (generador1 == generador2)
        );

        System.out.println(
                "Singleton Auditoria: "
                        + (auditoria1 == auditoria2)
        );

        System.out.println(
                "Prototype Curso: "
                        + (cursoA != cursoB)
        );

        System.out.println(
                "Prototype Horario: "
                        + (cursoA.getHorario()
                        != cursoB.getHorario())
        );

        System.out.println(
                "Prototype Aula: "
                        + (cursoA.getAula()
                        != cursoB.getAula())
        );

        System.out.println(
                "Prototype Evaluacion: "
                        + (cursoA.getEvaluacion()
                        != cursoB.getEvaluacion())
        );

        System.out.println(
                "Prototype Material: "
                        + (cursoA.getMaterialEducativo()
                        != cursoB.getMaterialEducativo())
        );
    }
}
