package pe.edu.utp.academico;

public class Evaluacion implements Prototipo<Evaluacion> {

    private String nombre;
    private double peso;
    private String fecha;

    public Evaluacion(String nombre, double peso, String fecha) {
        this.nombre = nombre;
        this.peso = peso;
        this.fecha = fecha;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public double getPeso() {
        return peso;
    }

    public void setPeso(double peso) {
        this.peso = peso;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    @Override
    public Evaluacion copiar() {
        return new Evaluacion(nombre, peso, fecha);
    }

    @Override
    public String toString() {
        return nombre + " | peso: " + peso + "% | fecha: " + fecha;
    }
}
