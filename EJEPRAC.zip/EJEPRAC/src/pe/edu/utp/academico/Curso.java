package pe.edu.utp.academico;

public class Curso implements Prototipo<Curso> {

    private String codigo;
    private String nombre;
    private String seccion;
    private int creditos;

    private Docente docente;
    private Horario horario;
    private Aula aula;
    private Evaluacion evaluacion;
    private MaterialEducativo materialEducativo;

    public Curso(String codigo,
                 String nombre,
                 String seccion,
                 int creditos,
                 Docente docente,
                 Horario horario,
                 Aula aula,
                 Evaluacion evaluacion,
                 MaterialEducativo materialEducativo) {

        this.codigo = codigo;
        this.nombre = nombre;
        this.seccion = seccion;
        this.creditos = creditos;
        this.docente = docente;
        this.horario = horario;
        this.aula = aula;
        this.evaluacion = evaluacion;
        this.materialEducativo = materialEducativo;
    }

    @Override
    public Curso copiar() {

        RegistroAuditoria.getInstancia().registrar(
                "Clonacion del curso " + codigo
        );

        return new Curso(
                codigo,
                nombre,
                seccion,
                creditos,
                docente,
                horario.copiar(),
                aula.copiar(),
                evaluacion.copiar(),
                materialEducativo.copiar()
        );
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getSeccion() {
        return seccion;
    }

    public void setSeccion(String seccion) {
        this.seccion = seccion;
    }

    public int getCreditos() {
        return creditos;
    }

    public void setCreditos(int creditos) {
        this.creditos = creditos;
    }

    public Docente getDocente() {
        return docente;
    }

    public void setDocente(Docente docente) {
        this.docente = docente;
    }

    public Horario getHorario() {
        return horario;
    }

    public void setHorario(Horario horario) {
        this.horario = horario;
    }

    public Aula getAula() {
        return aula;
    }

    public void setAula(Aula aula) {
        this.aula = aula;
    }

    public Evaluacion getEvaluacion() {
        return evaluacion;
    }

    public void setEvaluacion(Evaluacion evaluacion) {
        this.evaluacion = evaluacion;
    }

    public MaterialEducativo getMaterialEducativo() {
        return materialEducativo;
    }

    public void setMaterialEducativo(MaterialEducativo materialEducativo) {
        this.materialEducativo = materialEducativo;
    }

    public String resumen() {
        return codigo + " - " + nombre
                + " - seccion " + seccion
                + " - " + horario
                + " - aula " + aula.getCodigo()
                + " - docente " + docente.getNombre();
    }
}
