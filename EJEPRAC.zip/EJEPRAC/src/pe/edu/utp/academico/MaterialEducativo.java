package pe.edu.utp.academico;

public class MaterialEducativo implements Prototipo<MaterialEducativo> {

    private String titulo;
    private String formato;
    private String ubicacion;

    public MaterialEducativo(String titulo, String formato, String ubicacion) {
        this.titulo = titulo;
        this.formato = formato;
        this.ubicacion = ubicacion;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getFormato() {
        return formato;
    }

    public void setFormato(String formato) {
        this.formato = formato;
    }

    public String getUbicacion() {
        return ubicacion;
    }

    public void setUbicacion(String ubicacion) {
        this.ubicacion = ubicacion;
    }

    @Override
    public MaterialEducativo copiar() {
        return new MaterialEducativo(titulo, formato, ubicacion);
    }

    @Override
    public String toString() {
        return titulo + " | formato: " + formato
                + " | ubicacion: " + ubicacion;
    }
}
