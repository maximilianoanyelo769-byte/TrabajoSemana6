package pe.edu.utp.academico;

public class ConfiguracionAcademica {

    private static final ConfiguracionAcademica INSTANCIA =
            new ConfiguracionAcademica();

    private String institucion;
    private String periodo;
    private int maximoCreditos;

    private ConfiguracionAcademica() {
        this.institucion = "UTP";
        this.periodo = "2026-II";
        this.maximoCreditos = 24;
    }

    public static ConfiguracionAcademica getInstancia() {
        return INSTANCIA;
    }

    public String getInstitucion() {
        return institucion;
    }

    public void setInstitucion(String institucion) {
        this.institucion = institucion;
    }

    public String getPeriodo() {
        return periodo;
    }

    public void setPeriodo(String periodo) {
        this.periodo = periodo;
    }

    public int getMaximoCreditos() {
        return maximoCreditos;
    }

    public void setMaximoCreditos(int maximoCreditos) {
        this.maximoCreditos = maximoCreditos;
    }

    public String resumen() {
        return institucion + " | periodo " + periodo
                + " | maximo de creditos " + maximoCreditos;
    }
}
