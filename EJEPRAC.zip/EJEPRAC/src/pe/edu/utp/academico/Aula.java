package pe.edu.utp.academico;

public class Aula implements Prototipo<Aula> {

    private String codigo;
    private int capacidad;
    private String tipo;

    public Aula(String codigo, int capacidad, String tipo) {
        this.codigo = codigo;
        this.capacidad = capacidad;
        this.tipo = tipo;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public int getCapacidad() {
        return capacidad;
    }

    public void setCapacidad(int capacidad) {
        this.capacidad = capacidad;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    @Override
    public Aula copiar() {
        return new Aula(codigo, capacidad, tipo);
    }

    @Override
    public String toString() {
        return codigo + " | capacidad: " + capacidad + " | tipo: " + tipo;
    }
}
