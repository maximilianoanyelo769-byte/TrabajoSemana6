package pe.edu.utp.academico;

import java.util.ArrayList;
import java.util.List;

public class Estudiante {

    private String codigo;
    private String nombre;
    private String correo;

    private final List<Curso> cursos = new ArrayList<>();

    public Estudiante(String codigo, String nombre, String correo) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.correo = correo;
    }

    public void matricular(Curso curso) {
        cursos.add(curso);
    }

    public String mostrarCursos() {

        StringBuilder resultado =
                new StringBuilder(nombre + " esta matriculado en:\n");

        for (Curso curso : cursos) {
            resultado.append("- ")
                    .append(curso.resumen())
                    .append("\n");
        }

        return resultado.toString();
    }

    public String getCodigo() {
        return codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public String getCorreo() {
        return correo;
    }
}
